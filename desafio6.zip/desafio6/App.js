import React, { useState } from 'react';
import { View, Text, TouchableOpacity, ActivityIndicator, StyleSheet, Image } from 'react-native';

const QUIZ = [
  {
    id: 1,
    pergunta: 'Quem é o protagonista da Parte 1?',
    imagem: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQaNECndCNlDi6Nvy2T_xLHV45lFdikI0L10Q&s', 
    opcoes: ['Jotaro Kujo', 'Jonathan Joestar', 'Joseph Joestar', 'Josuke Higashikata'],
    respostaCerta: 1
  },
  {
    id: 2,
    pergunta: 'Qual o nome do vampiro principal da Parte 1?',
    imagem: 'https://static.jojowiki.com/images/3/35/latest/20201217185341/StoneMaskFilm.png', 
    opcoes: ['Kars', 'Dio', 'Pucci', 'Kira'],
    respostaCerta: 1
  },
  {
    id: 3,
    pergunta: 'Qual o stand do Jotaro?',
    imagem: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTzx_KvtcgMiIR6Rt18tVGSiHHt0GCC0JUnUQ&s',
    opcoes: ['Crazy Diamond', 'Gold Experience', 'Star Platinum', 'The World'],
    respostaCerta: 2
  },
  {
    id: 4,
    pergunta: 'Quem é o protagonista de Diamond is Unbreakable?',
    imagem: 'https://i.pinimg.com/736x/89/86/41/898641dd64393bac97cbd95522c34bbb.jpg',
    opcoes: ['Jolyne Kujo', 'Josuke Higashikata', 'Johnny Joestar', 'Giorno Giovanna'],
    respostaCerta: 1
  },
  {
    id: 5,
    pergunta: 'Qual stand pode parar o tempo?',
    imagem: 'https://pbs.twimg.com/media/EeoI9qrXsAA7oWA.jpg',
    opcoes: ['Aero Smith', 'Silver Chariot', 'Hermit Purple', 'The World'],
    respostaCerta: 3
  },
  {
    id: 6,
    pergunta: 'quem é o vilão principal da Parte 4?',
    imagem: 'https://images.steamusercontent.com/ugc/999141806430406191/A681AB1844CD8B137F12987354EC91DF73095BAF/?imw=5000&imh=5000&ima=fit&impolicy=Letterbox&imcolor=%23000000&letterbox=false',
    opcoes: ['Dio', 'Yoshikage Kira', 'Kars', 'Diavolo'],
    respostaCerta: 1
  },
  {
    id: 7,
    pergunta: 'Qual o nome do stand do Giorno?',
    imagem: 'https://i.pinimg.com/474x/85/86/a8/8586a8a5eb8409e6e1365572a6d4e6ae.jpg',
    opcoes: ['Stone Free', 'Gold Experience', 'Sticky Fingers', 'King Crimson'],
    respostaCerta: 1
  },
  {
    id: 8,
    pergunta: 'Quem é a filha do Jotaro?',
    imagem: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ2g1x6ZQfJnc-I5aGaU6iZADcFnLWk3oUQ0A&s',
    opcoes: ['Trish Una', 'Erina Joestar', 'Jolyne Kujo', 'Suzi Q'],
    respostaCerta: 2
  },
  {
    id: 9,
    pergunta: 'Qual desses NÃO é um JoJo?',
    imagem: 'https://i.pinimg.com/736x/87/2a/23/872a235af6f74c3c371536fb533c9e20.jpg',
    opcoes: ['Jotaro', 'Joseph', 'Polnareff', 'Johnny'],
    respostaCerta: 2
  },
  {
    id: 10,
    pergunta: 'Qual o stand de Johnny (Parte 7)?',
    imagem: 'https://i.pinimg.com/736x/03/b1/74/03b1741898a290614e04d8210202b4ef.jpg',
    opcoes: ['Tusk Act 1', 'Tusk Act 2', 'Tusk Act 3', 'Todas as alternativas'],
    respostaCerta: 3
  }
];

export default function AppQuiz() {
  const [telaAtual, setTelaAtual] = useState('inicio');
  const [perguntaAtual, setPerguntaAtual] = useState(0);
  const [pontuacao, setPontuacao] = useState(0);
  const [carregando, setCarregando] = useState(false);

  const [opcaoSelecionada, setOpcaoSelecionada] = useState(null);
  const [respondido, setRespondido] = useState(false);

  function iniciarJogo() {
    setPerguntaAtual(0);
    setPontuacao(0);
    setOpcaoSelecionada(null);
    setRespondido(false);
    setTelaAtual('quiz');
  }

  function voltarAoInicio() {
    setTelaAtual('inicio');
  }

  function responder(indiceClicado) {
    if (respondido) return; 

    const pergunta = QUIZ[perguntaAtual];
    setOpcaoSelecionada(indiceClicado);
    setRespondido(true);

    if (indiceClicado === pergunta.respostaCerta) {
      setPontuacao(pontuacao + 1);
    }

    
    setTimeout(() => {
      setCarregando(true);

     
      setTimeout(() => {
        if (perguntaAtual + 1 < QUIZ.length) {
          setPerguntaAtual(perguntaAtual + 1);
        } else {
          setTelaAtual('resultado');
        }
        
        
        setOpcaoSelecionada(null);
        setRespondido(false);
        setCarregando(false);
      }, 1000);

    }, 1000);
  }


  function obterEstiloOpcao(index, respostaCerta) {
    if (!respondido) return styles.botaoOpcao; // Estado normal

    if (index === respostaCerta) {
      return [styles.botaoOpcao, styles.botaoCorreto]; // Sempre verde se for a certa
    }

    if (index === opcaoSelecionada && opcaoSelecionada !== respostaCerta) {
      return [styles.botaoOpcao, styles.botaoErrado]; // Vermelho se o usuário errou
    }

    return [styles.botaoOpcao, { opacity: 0.6 }]; // Opacidade nas outras opções não clicadas
  }

  function obterEstiloTextoOpcao(index, respostaCerta) {
    if (!respondido) return styles.textoOpcao;
    if (index === respostaCerta || (index === opcaoSelecionada && opcaoSelecionada !== respostaCerta)) {
      return [styles.textoOpcao, { color: 'white' }]; // Texto branco para melhor contraste
    }
    return styles.textoOpcao;
  }

  // ==========================================
  // AS TELAS
  // ==========================================
  if (telaAtual === 'inicio') {
    return (
      <View style={styles.telaCentrada}>
        <Image
          source={{ uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSfe2awAmf1RoKZ75TZRElb5uIRX1IMFZFocw&s' }}
          style={styles.logoInicial}
        />
        <Text style={styles.tituloPrincipal}>Quiz Bizarro</Text>
        <Text style={styles.subtituloInicio}>Teste seus conhecimentos em JoJo`s Bizarre Adventure!</Text>
        <TouchableOpacity style={styles.botaoIniciar} onPress={iniciarJogo} activeOpacity={0.8}>
          <Text style={styles.textoBotaoIniciar}>INICIAR JOGO</Text>
        </TouchableOpacity>
      </View>
    );
  }

  if (telaAtual === 'resultado') {
    return (
      <View style={styles.telaCentrada}>
        <Text style={styles.iconeGrande}>🏆</Text>
        <Text style={styles.titulo}>Fim de Jogo!</Text>
        <Text style={styles.subtitulo}>Você acertou {pontuacao} de {QUIZ.length} perguntas.</Text>
        <TouchableOpacity style={styles.botaoAcao} onPress={voltarAoInicio} activeOpacity={0.8}>
          <Text style={styles.textoBotaoAcao}>Voltar ao Início</Text>
        </TouchableOpacity>
      </View>
    );
  }

  if (carregando) {
    return (
      <View style={styles.telaCentrada}>
        <ActivityIndicator size="large" color="#3b82f6" />
        <Text style={styles.textoCarregando}>Validando resposta...</Text>
      </View>
    );
  }

  const pergunta = QUIZ[perguntaAtual];

  return (
    <View style={styles.tela}>
      <View style={styles.cabecalho}>
        <Text style={styles.progresso}>Pergunta {perguntaAtual + 1} de {QUIZ.length}</Text>
        <Text style={styles.points}>Points: {pontuacao}</Text>
      </View>

      {pergunta.imagem && (
        <Image source={{ uri: pergunta.imagem }} style={styles.imagemPergunta} />
      )}

      <View style={styles.cartaoPergunta}>
        <Text style={styles.textoPergunta}>{pergunta.pergunta}</Text>
      </View>

      <View style={styles.areaOpcoes}>
        {pergunta.opcoes.map((opcao, index) => (
          <TouchableOpacity
            key={index}
            style={obterEstiloOpcao(index, pergunta.respostaCerta)}
            onPress={() => responder(index)}
            disabled={respondido} // Desabilita o botão após clicar
            activeOpacity={0.7}
          >
            <Text style={obterEstiloTextoOpcao(index, pergunta.respostaCerta)}>{opcao}</Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
}

// ==========================================
// ESTILOS
// ==========================================
const styles = StyleSheet.create({
  tela: { flex: 1, backgroundColor: '#f8fafc', padding: 20, paddingTop: 50 },
  telaCentrada: { flex: 1, backgroundColor: '#f8fafc', justifyContent: 'center', alignItems: 'center', padding: 20 },
  logoInicial: { width: 260, height: 130, marginBottom: 20 },
  
  imagemPergunta: { 
    width: '100%', 
    height: 160, 
    borderRadius: 15, 
    marginBottom: 15,
    resizeMode: 'cover' 
  },

  tituloPrincipal: { fontSize: 36, fontWeight: '900', color: '#1e293b', marginBottom: 10, textAlign: 'center' },
  subtituloInicio: { fontSize: 16, color: '#64748b', marginBottom: 50, textAlign: 'center', paddingHorizontal: 20 },
  botaoIniciar: { backgroundColor: '#10b981', paddingVertical: 20, paddingHorizontal: 40, borderRadius: 20, width: '100%', maxWidth: 300, shadowColor: '#10b981', shadowOpacity: 0.4, shadowRadius: 15, elevation: 8, alignItems: 'center' },
  textoBotaoIniciar: { color: 'white', fontSize: 20, fontWeight: '900', letterSpacing: 1 },
  
  cabecalho: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 20, paddingHorizontal: 10 },
  progresso: { fontSize: 16, fontWeight: '700', color: '#64748b' },
  points: { fontSize: 16, fontWeight: '800', color: '#3b82f6' },

  cartaoPergunta: { backgroundColor: 'white', padding: 20, borderRadius: 20, marginBottom: 20, shadowColor: '#0f172a', shadowOpacity: 0.05, shadowRadius: 15, elevation: 5, minHeight: 100, justifyContent: 'center' },
  
  textoPergunta: { fontSize: 20, fontWeight: '800', color: '#1e293b', textAlign: 'center', lineHeight: 26 },
  areaOpcoes: { flex: 1 },
  
  botaoOpcao: { backgroundColor: 'white', padding: 16, borderRadius: 15, marginBottom: 12, borderWidth: 2, borderColor: '#e2e8f0' },
  
  
  botaoCorreto: { backgroundColor: '#10b981', borderColor: '#059669' }, 
  botaoErrado: { backgroundColor: '#ef4444', borderColor: '#dc2626' },

  
  textoOpcao: { fontSize: 16, color: '#334155', fontWeight: '600', textAlign: 'center' },
  iconeGrande: { fontSize: 80, marginBottom: 20 },
  titulo: { fontSize: 32, fontWeight: '900', color: '#0f172a', marginBottom: 10 },
  subtitulo: { fontSize: 18, color: '#64748b', marginBottom: 40 },
  botaoAcao: { backgroundColor: '#3b82f6', paddingVertical: 18, paddingHorizontal: 40, borderRadius: 16, width: '100%', maxWidth: 300, alignItems: 'center' },
  textoBotaoAcao: { color: 'white', fontSize: 18, fontWeight: '800' },
  textoCarregando: { marginTop: 20, fontSize: 18, fontWeight: '600', color: '#3b82f6' }
});